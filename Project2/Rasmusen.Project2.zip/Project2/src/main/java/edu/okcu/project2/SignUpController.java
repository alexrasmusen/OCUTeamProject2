package edu.okcu.project2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.mindrot.jbcrypt.BCrypt;
import java.io.File;
import java.io.IOException;
import java.io.*;


public class SignUpController {

    @FXML
    private Label lblSignUp;
    @FXML
    private Label lblName;
    @FXML
    private Label lblEmail;
    @FXML
    private Label lblPassword;
    @FXML
    private TextField txtfieldName;
    @FXML
    private TextField txtfieldEmail;
    @FXML
    private TextField txtfieldPassword;

    String SignUpName;
    String SignUpEmail;
    String SignUpPassword;
    public void signUp(Stage stage) throws IOException {

    }
    protected void onSecondSignUpButtonClick(ActionEvent actionEvent){
        SignUpName = txtfieldName.getText();
        SignUpEmail = txtfieldEmail.getText();
        SignUpPassword = txtfieldPassword.getText();

        File file = new File("C\\Users\\alex1\\OneDrive\\Desktop\\signUp.txt");
        FileWriter info = null;
        try {
            info = new FileWriter(file);
            info.write(SignUpName + ", ");
            info.write(SignUpEmail + ", ");
            info.write(SignUpPassword + ", ");
            info.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    protected void onCancelButtonClick(ActionEvent actionEvent) {

    }

}
